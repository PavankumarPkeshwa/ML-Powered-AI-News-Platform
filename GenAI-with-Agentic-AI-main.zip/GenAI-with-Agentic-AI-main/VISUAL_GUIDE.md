# 🎨 Visual Project Guide - GenAI-with-Agentic-AI

## System Architecture Overview

```
┌────────────────────────────────────────────────────────────────────────────┐
│                            USER / CLIENT                                   │
│                    (Browser, curl, Python Script)                          │
└──────────────────────────────┬─────────────────────────────────────────────┘
                               │ HTTP/REST Requests
                               ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                          FASTAPI SERVER                                     │
│                      (Port 8000, Uvicorn)                                   │
│                         main.py                                             │
├────────────────────────────────────────────────────────────────────────────┤
│                         API ROUTES                                          │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐             │
│  │ GET /        │ GET /scr-    │ POST /rag/   │ GET /docs    │             │
│  │ Health Check │ aper/scrape  │ ask (RAG Q&A)│ API Docs     │             │
│  └──────────────┴──────────────┴──────────────┴──────────────┘             │
└────────────────────┬─────────────────────────┬─────────────────────────────┘
                     │                         │
        ┌────────────▼───────────┐  ┌──────────▼──────────────┐
        │   SCRAPING PIPELINE    │  │    RAG Q&A PIPELINE     │
        │   (Web Scraper)        │  │   (Question Answering)  │
        └────────────┬───────────┘  └──────────┬──────────────┘
                     │                         │
         ┌───────────┴──────────┐      ┌──────┴──────────┐
         │                      │      │                 │
         ▼                      ▼      ▼                 ▼
    ┌─────────────┐      ┌─────────────────────────────────────┐
    │  NEWS AGENT │      │    VECTOR DATABASE & EMBEDDINGS     │
    │  (Scraper & │      │                                     │
    │   Cleaner)  │      │  • ChromaDB (SQLite)               │
    │             │      │  • 384-dim embeddings              │
    │ • Fetch URL │      │  • Cosine similarity search        │
    │ • Parse HTML│      │  • Persistent storage              │
    │ • LLM Clean │      │                                     │
    └──────┬──────┘      └─────────────────────────────────────┘
           │                         ▲
           │                         │
           ▼                         │
    ┌─────────────────┐              │
    │ VALIDATOR AGENT │──────────────┘
    │                 │
    │ • Check length  │
    │ • Detect dups   │
    │ • Quality check │
    │ • Spam filter   │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │ MANAGER AGENT   │
    │ (Orchestrator)  │
    │                 │
    │ Coordinates:    │
    │ 1. Fetch        │
    │ 2. Clean        │
    │ 3. Validate     │
    │ 4. Store        │
    └─────────────────┘
```

---

## 🔄 Detailed Scraping Flow

```
START: User scrapes a URL
    ↓
    ║ curl "http://localhost:8000/scraper/scrape?url=https://example.com/news"
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 1: NEWS AGENT - FETCH URL                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  news_agent.py:fetch_url()                                 │
│  ├─ Create User-Agent header                               │
│  ├─ Send HTTP GET request to URL                           │
│  └─ Receive HTML content (raw)                             │
│                                                              │
│  Input:  "https://example.com/article"                     │
│  Output: "<html><body>...</body></html>"                   │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 2: NEWS AGENT - EXTRACT TEXT                           │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  news_agent.py:extract_main_text_from_html()               │
│  ├─ Parse HTML with BeautifulSoup                          │
│  ├─ Try Strategy 1: Find <article> tag                     │
│  │  └─ If found & >200 chars → Return                      │
│  ├─ Try Strategy 2: Find all <p> tags                      │
│  │  └─ Extract & combine paragraphs                        │
│  └─ Strategy 3: Use <body> text as last resort             │
│                                                              │
│  Input:  "<html><article>The news article...</article></   │
│  Output: "The news article..."                             │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 3: NEWS AGENT - CLEAN WITH LLM                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  news_agent.py:clean_text_with_llm()                       │
│  ├─ Load LocalLLM (google/flan-t5-base)                    │
│  ├─ Create prompt asking to:                               │
│  │  ├─ Remove ads/navigation/timestamps                    │
│  │  ├─ Extract title                                        │
│  │  └─ Extract clean content                                │
│  └─ Return structured dict {title, content}                │
│                                                              │
│  Input:  Raw text with ads/nav                             │
│  Output: {"title": "Article Title",                        │
│           "content": "Clean article text..."}              │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 4: VALIDATOR AGENT - VALIDATE QUALITY                 │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  validator_agent.py:validate_article()                     │
│                                                              │
│  Check 1: Length Validation                                │
│  ├─ is_long_enough(text)                                   │
│  └─ Require minimum 60 words                               │
│     Result: ✅ PASS or ❌ FAIL                              │
│                                                              │
│  Check 2: Duplicate Detection                              │
│  ├─ is_duplicate(text)                                     │
│  ├─ Convert to embedding (384-dim vector)                  │
│  ├─ Search ChromaDB for similar articles                   │
│  ├─ Compare cosine similarity                              │
│  └─ Threshold: 0.85 (85% similar = duplicate)              │
│     Result: ✅ UNIQUE or ❌ DUPLICATE                       │
│                                                              │
│  Check 3: Quality Validation                               │
│  ├─ llm_validate_relevance(text)                           │
│  ├─ Check for spam keywords                                │
│  ├─ Verify sentence structure                              │
│  ├─ Assess relevance                                        │
│  └─ Check safety                                            │
│     Result: ✅ VALID or ❌ SPAM/LOW QUALITY                 │
│                                                              │
│  Output: {                                                  │
│    "length_ok": true,                                      │
│    "is_duplicate": false,                                  │
│    "llm_check": {...},                                     │
│    "final_decision": "approve" or "reject"                 │
│  }                                                           │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ DECISION POINT                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  if final_decision == "approve":                           │
│     → Continue to storage (Step 5)                         │
│  else:                                                      │
│     → Return {status: "rejected", reason: "..."}           │
│     → End workflow                                          │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 5: MANAGER AGENT - STORE IN VECTOR DB                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  manager_agent.py:ingest_url()                             │
│  ├─ Create LangChain Document                              │
│  │  ├─ page_content: article text                          │
│  │  └─ metadata: {url, title, ...}                         │
│  ├─ Call embedder to convert to vector                     │
│  │  └─ 384-dimensional vector                              │
│  ├─ Store in ChromaDB                                      │
│  │  └─ Database: vector_store/chroma.sqlite3               │
│  └─ Persist to disk                                        │
│                                                              │
│  Input:  Document object                                   │
│  Output: Stored in DB with embedding                       │
└─────────────────────────────────────────────────────────────┘
    ↓
END: Return Success Response
    ║ {
    ║   "status": "ingested",
    ║   "metadata": {
    ║     "title": "Article Title",
    ║     "length": 450,
    ║     "validation": {...}
    ║   }
    ║ }
```

---

## 🧠 RAG Q&A Flow

```
START: User asks a question
    ↓
    ║ curl -X POST "http://localhost:8000/rag/ask?question=What+is+AI?"
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 1: EMBED THE QUESTION                                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  embedder.py:get_embedding_model()                         │
│  ├─ Load SentenceTransformer (all-MiniLM-L6-v2)            │
│  ├─ Convert question string to 384-dimensional vector      │
│  └─ This vector represents the semantic meaning             │
│                                                              │
│  Input:  "What is artificial intelligence?"                │
│  Vector: [0.234, -0.456, 0.789, ..., 0.123]  (384 dims)   │
│                                                              │
│  Visual Representation:                                     │
│  ┌─────────────────────────────────────────┐               │
│  │ Vector Space (384 dimensions)            │               │
│  │                                          │               │
│  │          📍 Question Vector              │               │
│  │         /                                │               │
│  │        /  (This is the semantic meaning) │               │
│  │                                          │               │
│  └─────────────────────────────────────────┘               │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 2: SEARCH VECTOR DATABASE                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  vectordb.py:similarity_search()                           │
│  ├─ Compare question vector with all stored vectors        │
│  ├─ Calculate cosine similarity (0-1 score)                │
│  ├─ Find top-3 most similar documents                      │
│  └─ Return Document objects with metadata                  │
│                                                              │
│  Visual:                                                     │
│  ┌──────────────────────────────────────────┐              │
│  │ Vector DB Space                          │              │
│  │                                          │              │
│  │   📍 Q: "What is AI?"                   │              │
│  │    ↓↓↓                                   │              │
│  │   📄 Doc1: "AI is machine learning..." ↖ │ ✅ 0.92      │
│  │   📄 Doc2: "AI transforms tech..."     ↖ │ ✅ 0.87      │
│  │   📄 Doc3: "Deep learning intro..."    ↖ │ ✅ 0.81      │
│  │   📄 Doc4: "Programming tips..."          │ ❌ 0.23      │
│  │   📄 Doc5: "Coffee recipes..."            │ ❌ 0.15      │
│  │                                          │              │
│  │ Top-3 Selected ↗                         │              │
│  └──────────────────────────────────────────┘              │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 3: FORMAT CONTEXT                                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  rag_chain.py:format_docs()                                │
│  ├─ Take 3 retrieved documents                             │
│  ├─ Extract page_content from each                         │
│  ├─ Combine into single context string                     │
│  └─ Add separators between documents                       │
│                                                              │
│  Output Example:                                            │
│  ╔════════════════════════════════════════╗               │
│  ║ Document 1:                            ║               │
│  ║ "AI is machine learning that enables..." ║             │
│  ║                                        ║               │
│  ║ Document 2:                            ║               │
│  ║ "Artificial intelligence transforms..." ║             │
│  ║                                        ║               │
│  ║ Document 3:                            ║               │
│  ║ "Deep learning is a subset of AI..."   ║               │
│  ╚════════════════════════════════════════╝               │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 4: BUILD PROMPT                                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  rag_chain.py:build_prompt()                               │
│  ├─ Create PromptTemplate with variables:                  │
│  │  ├─ {context} - Retrieved documents                     │
│  │  └─ {question} - User's question                        │
│  └─ Fill in template                                       │
│                                                              │
│  Resulting Prompt:                                          │
│  ╔════════════════════════════════════════╗               │
│  ║ You are a factual News QA Agent.        ║               │
│  ║ Use ONLY the context provided.          ║               │
│  ║                                        ║               │
│  ║ CONTEXT:                               ║               │
│  ║ [Document 1 content here...]           ║               │
│  ║ [Document 2 content here...]           ║               │
│  ║ [Document 3 content here...]           ║               │
│  ║                                        ║               │
│  ║ QUESTION: What is artificial           ║               │
│  ║ intelligence?                           ║               │
│  ║                                        ║               │
│  ║ Answer concisely and do not hallucinate. ║              │
│  ╚════════════════════════════════════════╝               │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 5: LOCAL LLM GENERATES ANSWER                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  local_llm.py:LocalLLM.invoke()                            │
│  ├─ Load model: google/flan-t5-base                        │
│  │  └─ 990MB, cached in ~/.cache/huggingface/              │
│  ├─ Send prompt to model                                   │
│  ├─ Model processes (2-3 seconds on CPU)                   │
│  └─ Return generated text response                         │
│                                                              │
│  Generated Answer:                                          │
│  ╔════════════════════════════════════════╗               │
│  ║ "Artificial intelligence (AI) is a     ║               │
│  ║ field of computer science that enables ║               │
│  ║ machines to learn from data and make   ║               │
│  ║ intelligent decisions. It includes     ║               │
│  ║ machine learning and deep learning     ║               │
│  ║ as key subfields."                     ║               │
│  ╚════════════════════════════════════════╝               │
└─────────────────────────────────────────────────────────────┘
    ↓
END: Return Response to User
    ║ {
    ║   "question": "What is artificial intelligence?",
    ║   "answer": "Artificial intelligence (AI) is..."
    ║ }
```

---

## 📊 Component Interaction Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    fastapi (main.py)                        │
│            Handles HTTP requests & routing                  │
└──────────────┬────────────────────────┬──────────────────────┘
               │                        │
    ┌──────────▼────────────┐  ┌───────▼──────────────┐
    │   /scraper/scrape     │  │    /rag/ask (RAG)    │
    │   (Web Scraping)      │  │  (Q&A System)        │
    └──────────┬────────────┘  └───────┬──────────────┘
               │                       │
     ┌─────────┴─────────┐             │
     │                   │             │
     ▼                   ▼             │
  ┌────────────┐  ┌──────────────┐   │
  │NewsAgent   │  │ManagerAgent  │   │
  │(Scraping)  │  │(Orchestrator)│   │
  └─────┬──────┘  └──────────────┘   │
        │                             │
        │ (uses)                      │
        │                             │
     ┌──▼────────────────┐            │
     │ LocalLLM          │            │
     │ (google/flan-t5)  │            │
     └──────────────────┘            │
                                     │
                                     ▼
            ┌────────────────────────────────────────┐
            │  VECTOR DATABASE                       │
            │  (ChromaDB with SQLite)                │
            │                                        │
            │  ┌──────────────────────────────────┐ │
            │  │ Stored Articles                  │ │
            │  │ ├─ Doc1 + 384-dim embedding     │ │
            │  │ ├─ Doc2 + 384-dim embedding     │ │
            │  │ ├─ Doc3 + 384-dim embedding     │ │
            │  │ └─ ... (many more)              │ │
            │  └──────────────────────────────────┘ │
            │                                        │
            │  ┌──────────────────────────────────┐ │
            │  │ Embeddings Model                 │ │
            │  │ (SentenceTransformer)            │ │
            │  │ Text → 384-dim vector            │ │
            │  └──────────────────────────────────┘ │
            │                                        │
            │  ┌──────────────────────────────────┐ │
            │  │ Search Engine                    │ │
            │  │ Cosine similarity search         │ │
            │  │ Returns top-K documents          │ │
            │  └──────────────────────────────────┘ │
            └────────────────────────────────────────┘
                        ▲                │
                        │                │
              (stores & searches)        │
                        │                │
              (retrieves docs)           │ (uses in RAG)
                        │                │
                        └────────────────▼
                          ┌──────────────────┐
                          │ RAG Chain        │
                          │ (rag_chain.py)   │
                          │                  │
                          │ 1. Embed query   │
                          │ 2. Search DB     │
                          │ 3. Format context│
                          │ 4. Call LLM      │
                          │ 5. Return answer │
                          └──────────────────┘
```

---

## 🛠️ Validation Flow Diagram

```
Article Text Input
    ↓
    ▼
┌────────────────────────────────────────────────────────┐
│ validator_agent.py:validate_article()                 │
│                                                        │
│ ┌──────────────────────────────────────────────────┐ │
│ │ CHECK 1: LENGTH VALIDATION                      │ │
│ │                                                 │ │
│ │  Word Count: 45 words                          │ │
│ │  Minimum Required: 60 words                    │ │
│ │  Status: ❌ FAIL (needs 60+ words)             │ │
│ │  Decision: REJECT                              │ │
│ └──────────────────────────────────────────────────┘ │
│                        OR                            │
│ ┌──────────────────────────────────────────────────┐ │
│ │ CHECK 1: LENGTH VALIDATION                      │ │
│ │                                                 │ │
│ │  Word Count: 250 words                         │ │
│ │  Minimum Required: 60 words                    │ │
│ │  Status: ✅ PASS                               │ │
│ │  Continue to Check 2...                        │ │
│ └──────────────────────────────────────────────────┘ │
│                        │                            │
│                        ▼                            │
│ ┌──────────────────────────────────────────────────┐ │
│ │ CHECK 2: DUPLICATE DETECTION                   │ │
│ │                                                 │ │
│ │  1. Embed article: [0.23, -0.45, ...]  384-dim│ │
│ │  2. Search DB for similar vectors              │ │
│ │  3. Find most similar: 0.92 similarity        │ │
│ │     (92% similar)                              │ │
│ │  4. Threshold: 0.85                            │ │
│ │  5. Status: ❌ DUPLICATE (>85%)                │ │
│ │  Decision: REJECT                              │ │
│ └──────────────────────────────────────────────────┘ │
│                        OR                            │
│ ┌──────────────────────────────────────────────────┐ │
│ │ CHECK 2: DUPLICATE DETECTION                   │ │
│ │                                                 │ │
│ │  1. Embed article: [0.12, 0.34, ...]  384-dim │ │
│ │  2. Search DB for similar vectors              │ │
│ │  3. Find most similar: 0.73 similarity        │ │
│ │     (73% similar)                              │ │
│ │  4. Threshold: 0.85                            │ │
│ │  5. Status: ✅ UNIQUE (<85%)                   │ │
│ │  Continue to Check 3...                        │ │
│ └──────────────────────────────────────────────────┘ │
│                        │                            │
│                        ▼                            │
│ ┌──────────────────────────────────────────────────┐ │
│ │ CHECK 3: QUALITY & SPAM CHECK                  │ │
│ │                                                 │ │
│ │  1. Search for spam keywords:                  │ │
│ │     - "click here" ❌ Found                    │ │
│ │     - "buy now" ❌ Found                       │ │
│ │     - "subscribe" ✅ Not found                 │ │
│ │  2. Spam count: 2 (>3 = spam)                  │ │
│ │  3. Status: ✅ NOT SPAM                        │ │
│ │  4. Check sentence structure:                  │ │
│ │     - Sentences with >20 chars: 12             │ │
│ │     - Minimum required: 3                      │ │
│ │  5. Status: ✅ VALID STRUCTURE                 │ │
│ │  Decision: CONTINUE                            │ │
│ └──────────────────────────────────────────────────┘ │
│                                                      │
└──────────────────────────────────────────────────────┘
    ↓
┌────────────────────────────────────────────────────────┐
│ FINAL DECISION                                         │
│                                                        │
│ All checks passed?                                    │
│ ├─ Length: ✅ YES                                     │
│ ├─ Not Duplicate: ✅ YES                              │
│ ├─ Quality: ✅ YES                                    │
│ └─ Spam: ✅ NO                                        │
│                                                        │
│ ➜ DECISION: "APPROVE" ✅                              │
│ ➜ ACTION: Store in vector DB                         │
└────────────────────────────────────────────────────────┘
    ↓
Returns: {
    "length_ok": true,
    "is_duplicate": false,
    "llm_check": {...},
    "final_decision": "approve"
}
```

---

## 💾 Data Storage Architecture

```
┌──────────────────────────────────────────────────────────┐
│          VECTOR DATABASE STRUCTURE                       │
│     (vector_store/chroma.sqlite3)                        │
└──────────────────────────────────────────────────────────┘
                         │
                         ▼
    ┌────────────────────────────────────────┐
    │   COLLECTION: news_articles            │
    │                                        │
    │   ┌──────────────────────────────────┐ │
    │   │ DOCUMENT 1                       │ │
    │   ├──────────────────────────────────┤ │
    │   │ ID: abc123                       │ │
    │   │ Text: "Artificial intelligence..." │ │
    │   │ Metadata:                        │ │
    │   │  ├─ source: https://...          │ │
    │   │  ├─ title: "AI Explained"        │ │
    │   │ Embedding: [                     │ │
    │   │   0.234,  -0.456,  0.789, ...    │ │
    │   │   (384 dimensions total)         │ │
    │   │ ]                                │ │
    │   └──────────────────────────────────┘ │
    │                                        │
    │   ┌──────────────────────────────────┐ │
    │   │ DOCUMENT 2                       │ │
    │   ├──────────────────────────────────┤ │
    │   │ ID: def456                       │ │
    │   │ Text: "Machine learning guide..." │ │
    │   │ Metadata:                        │ │
    │   │  ├─ source: https://...          │ │
    │   │  ├─ title: "ML Basics"           │ │
    │   │ Embedding: [                     │ │
    │   │   0.112,  0.334,  -0.556, ...    │ │
    │   │ ]                                │ │
    │   └──────────────────────────────────┘ │
    │                                        │
    │   ┌──────────────────────────────────┐ │
    │   │ DOCUMENT 3                       │ │
    │   ├──────────────────────────────────┤ │
    │   │ ID: ghi789                       │ │
    │   │ Text: "Deep learning explained..." │ │
    │   │ Metadata:                        │ │
    │   │  ├─ source: https://...          │ │
    │   │  ├─ title: "Deep Learning 101"   │ │
    │   │ Embedding: [                     │ │
    │   │   0.667,  -0.123,  0.445, ...    │ │
    │   │ ]                                │ │
    │   └──────────────────────────────────┘ │
    │                                        │
    │   ... (more documents)                 │
    └────────────────────────────────────────┘

SEARCH EXAMPLE:
    Query: "What is machine learning?"
    ↓
    Query Embedding: [0.234, 0.456, -0.789, ...]
    ↓
    Similarity Scores:
    ├─ Document 1: 0.89 ✅ RELEVANT
    ├─ Document 2: 0.92 ✅ MOST RELEVANT
    ├─ Document 3: 0.76 ✅ RELEVANT
    ├─ Document 4: 0.34 ❌ NOT RELEVANT
    └─ Document 5: 0.15 ❌ NOT RELEVANT
    ↓
    Return Top-3: [Document 2, Document 1, Document 3]
```

---

## 🔌 API Request/Response Flow

```
CLIENT SIDE                          SERVER SIDE
─────────────────────────────────────────────────────────

1. HEALTH CHECK
┌──────────────────┐                ┌──────────────────┐
│ curl http://     │                │                  │
│ localhost:8000/  │──GET ──────────→│ @app.get("/")    │
│                  │                │ return status    │
│                  │←──JSON ────────│ {"status": "..."}│
└──────────────────┘                └──────────────────┘


2. SCRAPE ARTICLE
┌──────────────────┐                ┌──────────────────┐
│ curl http://     │                │ scraper_routes   │
│ localhost:8000/  │                │ @router.get      │
│ scraper/scrape   │──GET ──────────→│ ("/scrape")      │
│ ?url=...         │                │ ↓                │
│                  │                │ manager_agent    │
│                  │                │ .ingest_url()    │
│                  │                │ ↓                │
│                  │                │ news_agent       │
│                  │                │ .fetch_url()     │
│                  │                │ .extract_text()  │
│                  │                │ .clean_text()    │
│                  │                │ ↓                │
│                  │                │ validator_agent  │
│                  │                │ .validate()      │
│                  │                │ ↓                │
│                  │                │ vectordb.add()   │
│                  │                │                  │
│                  │←──JSON ────────│ {"status":       │
│                  │   (30-60s)      │  "ingested"}     │
└──────────────────┘                └──────────────────┘


3. RAG QUESTION
┌──────────────────┐                ┌──────────────────┐
│ curl -X POST     │                │ rag_routes       │
│ http://localhost │                │ @router.post     │
│ :8000/rag/ask    │──POST ─────────→│ ("/ask")         │
│ ?question=...    │                │ ↓                │
│                  │                │ rag_chain        │
│                  │                │ .invoke()        │
│                  │                │ ├─ embedder      │
│                  │                │ ├─ vectordb      │
│                  │                │ ├─ rag_chain     │
│                  │                │ └─ local_llm     │
│                  │                │                  │
│                  │←──JSON ────────│ {"question":     │
│                  │   (2-3s)        │  "...",          │
│                  │                │  "answer": "..."}│
└──────────────────┘                └──────────────────┘


RESPONSE TIMELINE FOR RAG QUERY:
Time: 0ms       → Server receives request
      100ms     → Question embedded (384-dim vector)
      150ms     → Vector DB search complete (top-3 docs)
      200ms     → Context formatted
      300ms     → Prompt template filled
      500ms     → LLM loading model (if not cached)
      2500ms    → LLM inference complete
      2600ms    → Response sent to client

Total: ~2.6 seconds on CPU
```

---

## 🚀 Deployment Stack

```
┌─────────────────────────────────────────────────────────┐
│                    DOCKER/SERVER                        │
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │ Python 3.12 Runtime                             │ │
│  │                                                 │ │
│  │  ┌────────────────────────────────────────────┐ │ │
│  │  │ Uvicorn Server (HTTP)                      │ │ │
│  │  │ Port: 8000                                 │ │ │
│  │  │ Workers: 1 (can scale)                     │ │ │
│  │  │                                            │ │ │
│  │  │ ┌──────────────────────────────────────┐ │ │ │
│  │  │ │ FastAPI Application (main.py)        │ │ │ │
│  │  │ │                                      │ │ │ │
│  │  │ │ ├─ /scraper routes                   │ │ │ │
│  │  │ │ ├─ /rag routes                       │ │ │ │
│  │  │ │ ├─ /agent routes                     │ │ │ │
│  │  │ │ └─ / (health check)                  │ │ │ │
│  │  │ └──────────────────────────────────────┘ │ │ │
│  │  │           ↓ uses                          │ │ │
│  │  │ ┌──────────────────────────────────────┐ │ │ │
│  │  │ │ Business Logic (agents, RAG)         │ │ │ │
│  │  │ │ ├─ News Agent                        │ │ │ │
│  │  │ │ ├─ Validator Agent                   │ │ │ │
│  │  │ │ ├─ Manager Agent                     │ │ │ │
│  │  │ │ ├─ RAG Chain                         │ │ │ │
│  │  │ │ └─ Local LLM                         │ │ │ │
│  │  │ └──────────────────────────────────────┘ │ │ │
│  │  │           ↓ uses                          │ │ │
│  │  │ ┌──────────────────────────────────────┐ │ │ │
│  │  │ │ Data Layer                           │ │ │ │
│  │  │ ├─ ChromaDB (vector_store/)            │ │ │ │
│  │  │ ├─ Models Cache (~/.cache/huggingface/)│ │ │ │
│  │  │ └─ Local Files (data/)                 │ │ │ │
│  │  └────────────────────────────────────────┘ │ │ │
│  │                                             │ │ │
│  │  Memory Usage:                             │ │ │
│  │  • FastAPI: 100MB                         │ │ │
│  │  • LLM Model: 1.5GB (cached)              │ │ │
│  │  • Embeddings: 200MB                      │ │ │
│  │  • Vector DB: 50MB + data                 │ │ │
│  │  ─────────────────────                   │ │ │
│  │  • Total: ~2GB RAM                        │ │ │
│  └──────────────────────────────────────────────┘ │
│                                                   │
│  Disk Usage:                                     │
│  • Models: ~1GB (cached)                        │
│  • Embeddings: ~90MB                           │
│  • Vector DB: Variable (per stored articles)    │
│  • Application code: ~50MB                      │
└─────────────────────────────────────────────────────┘
```

---

## 📈 Performance Comparison

```
OPERATION SPEED (on CPU)

Task                        Time        Notes
─────────────────────────────────────────────────────
1. Server Startup           <1s         FastAPI initialization
2. Health Check             <5ms        JSON response only
3. Embed 1 sentence         ~50ms       SentenceTransformer
4. Vector DB Search         <100ms      Cosine similarity
5. Scrape single URL        5-30s       Depends on website
6. Extract & parse HTML     1-2s        BeautifulSoup
7. LLM inference (first)     2-3s        Including model load
8. LLM inference (warm)      2s          Model cached
9. Clean text with LLM       1-2s        Per 500 words
10. Full RAG Q&A response    2-4s        All steps combined
11. Full scrape pipeline     30-60s      All validation steps

THROUGHPUT

Operation                   Throughput
─────────────────────────────────────────────────────
Embedding                   ~100 texts/second
Vector search               ~1000 queries/second
RAG queries                 ~20-30 queries/minute
Web scraping                ~10-20 articles/minute
LLM inference               ~5-10 inferences/minute
```

---

## 🎯 Key Features Summary

```
                    GenAI-with-Agentic-AI
                 Feature Architecture Map

┌────────────────────────────────────────────────────┐
│                                                    │
│  ┌──────────────────────────────────────────────┐ │
│  │ 🤖 AUTONOMOUS AGENTS                         │ │
│  │                                              │ │
│  │ News Agent         → Scrape & clean articles │ │
│  │ Validator Agent    → Quality control         │ │
│  │ Manager Agent      → Workflow orchestration  │ │
│  └──────────────────────────────────────────────┘ │
│                                                    │
│  ┌──────────────────────────────────────────────┐ │
│  │ 🧠 INTELLIGENCE                              │ │
│  │                                              │ │
│  │ Local LLM          → No API token needed     │ │
│  │ Embeddings         → Semantic understanding  │ │
│  │ RAG Pipeline       → Factual Q&A             │ │
│  └──────────────────────────────────────────────┘ │
│                                                    │
│  ┌──────────────────────────────────────────────┐ │
│  │ 💾 STORAGE                                   │ │
│  │                                              │ │
│  │ Vector Database    → ChromaDB with search   │ │
│  │ Persistent         → Survives restarts      │ │
│  │ Scalable           → Grows with articles    │ │
│  └──────────────────────────────────────────────┘ │
│                                                    │
│  ┌──────────────────────────────────────────────┐ │
│  │ 🔌 API                                       │ │
│  │                                              │ │
│  │ REST Endpoints     → 5 main endpoints       │ │
│  │ Swagger Docs       → Auto-generated UI      │ │
│  │ Scalable           → Ready for load balancer│ │
│  └──────────────────────────────────────────────┘ │
│                                                    │
└────────────────────────────────────────────────────┘
```

---

**This visual guide shows how every piece of your GenAI system works together! 🎨**
